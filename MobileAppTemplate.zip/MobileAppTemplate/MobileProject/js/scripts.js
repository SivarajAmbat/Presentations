﻿$(document).ready(function () {

    $(window).resize(function () {

        $('.center').css({
            position: 'absolute',
            left: ($('.intro').width()
              - $('.center').outerWidth()) / 2,
            top: ($('.intro').height()
              - $('.center').outerHeight()) / 2
        });

        $('.iphone-container').css({
            position: 'absolute',
            left: ($('.mock').width()
              - $('.iphone-container').outerWidth()) / 2,
            top: ($('.mock').height()
              - $('.iphone-container').outerHeight()) / 2
        });

    });

    $(window).resize();

  
    $(".cross").hide();
    $(".menu").hide();
    $(".hamburger").click(function () {
        $(".menu").slideToggle("slow", function () {
            $(".hamburger").hide();
            $(".cross").show();
        });
    });

    $(".cross").click(function () {
        $(".menu").slideToggle("slow", function () {
            $(".cross").hide();
            $(".hamburger").show();
        });
    });

    $(".menu a").click(function () {
        $(".menu").slideToggle("slow", function () {
            $(".cross").hide();
            $(".hamburger").show();
        });
    });

});
