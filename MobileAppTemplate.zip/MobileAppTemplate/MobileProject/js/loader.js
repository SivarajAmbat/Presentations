﻿
var app = angular.module("FoodiesApp", ["ngRoute"]);

app.config(function ($routeProvider) {
    $routeProvider
    .when("/home", { templateUrl: "/mobile/views/home.html" })
    .when("/about", { templateUrl: "/mobile/views/about.html" })
    .when("/contact", { templateUrl: "/mobile/views/contact.html" })
    .otherwise({ redirectTo: "/home" })
});

