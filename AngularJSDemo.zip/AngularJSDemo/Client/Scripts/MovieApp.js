﻿
var app = angular.module("MovieApp", ["ngRoute"]);

app.constant("ApiURL", "http://localhost:58606/api/Movie/");

var movieService = function($http,ApiURL){
	var getAll = function(){
		return $http.get(ApiURL);
	};
	var getById = function(id){
		return $http.get(ApiURL + id);
	};
	var update = function(movie){
		return $http.put(ApiURL + movie.Id, movie);
	};
	var create = function(movie){
		return $http.post(ApiURL, movie);
	};
	var destroy = function(movie){
	console.log(ApiURL + movie.Id);
		return $http.delete(ApiURL + movie.Id);
	};

	return {
		getAll :getAll, 
		getById : getById,
		update : update, 
		create : create, 
		delete : destroy
		};
};

app.factory("movieService", movieService);


var config = function($routeProvider){
	$routeProvider
		.when("/list",			{templateUrl: "/Client/Views/list.html"})
		.when("/details/:id",	{templateUrl: "/Client/Views/details.html"})
		.otherwise(				{redirectTo: "/list"});
};

app.config(config);



/* LISTCONTROLLER */

var listController = function($scope, movieService){
	movieService.getAll().
		success(function(data){
			$scope.movies = data;
		});

		$scope.delete = function(movie){
			movieService.delete(movie)
			.success(function(){
				removeMovieById(movie.Id);
			});
		};

		var removeMovieById = function(id){
			for(var i = 0;  i < $scope.movies.length; i++){
				if($scope.movies[i].Id == id){
					$scope.movies.splice(i,1);
					break;
				}
			}
		};

		$scope.create= function(){
			$scope.edit = {
				movie : {
					Title: "No Title", 
					Runtime : 0, 
					ReleaseYear : new Date().getFullYear()
				}
			};
		};

};
app.controller("ListController", listController);

/* DETAILSCONTROLLER */

var detailsController = function($scope, $routeParams, movieService){
	movieService.getById($routeParams.id)
		.success(function(data){
			$scope.movie = data;
		});

	$scope.edit = function(){
		$scope.edit.movie = angular.copy($scope.movie);
	};
}
app.controller("DetailsController", detailsController);


/* EDITCONTROLLER */

var editController = function($scope, movieService){
	$scope.isEditable = function(){
		return $scope.edit && $scope.edit.movie;
	};

	$scope.cancel = function(){
		$scope.edit.movie = null;
	};

	$scope.save = function(){
		if($scope.edit.movie.Id){
			updateMovie();
		}else{
			createMovie();
		}
	};

	var updateMovie = function(){
		movieService.update($scope.edit.movie)
			.success(function(){
				angular.extend($scope.movie, $scope.edit.movie);
				$scope.edit.movie = null;
			});
	};
	var createMovie = function(){
		movieService.create($scope.edit.movie)
			.success(function(movie){
				$scope.movies.push(movie);
				$scope.edit.movie = null;
			});
	};

};

app.controller("EditController", editController);